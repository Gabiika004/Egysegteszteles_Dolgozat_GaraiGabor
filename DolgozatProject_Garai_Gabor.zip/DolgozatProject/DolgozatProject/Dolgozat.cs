﻿namespace DolgozatProject
{
    public class Dolgozat
    {

        List<int> pontok;

        public Dolgozat()
        {
            this.pontok = new List<int>();
        }


        /// <summary>
        /// Felvesz egy pontot a "pontok" listába, ha megfelel a feltételeknek.
        /// </summary>
        /// <param name="x">Felvett pont a dolgozat eredménye alapján.</param>
        /// <exception cref="ArgumentException">Kivételt dob, ha a pont kevesebb min -1 vagy 100-nál nagyobb.</exception>
        public void PontFelvesz(int x)
        {
            
            if (x < -1 || x  > 100) 
            {
                throw new ArgumentException(nameof(x));
            }
            else
            {
                pontok.Add(x);

            }
        }


        /// <summary>
        /// Eldönti, a megadott pontszámok alapján, hogy mindenki megírta-e a dolgozatot.
        /// </summary>
        /// <returns>   Igaz értékkel tér vissza, ha a pontok között NEM talál -1 pontszmáot, 
        ///             fordított esetben a visszakapott érték hamis.
        /// </returns>
        public bool MindenkiMegirta()
        {
            if (pontok.Contains(-1))
            {
                return false;
            }
            return true;
        }


        /// <summary>
        /// Megszámolja és vissza adja a bukott diákok számát. Bukásnak számít minden szám, ami nem -1 és 50-nél kisebb.
        /// </summary>
        public int Bukas
        {
            get
            {
                return pontok.Where(x => x < 50 && x > -1).Count();
            }
        }


        /// <summary>
        /// Megszámolja és vissza adja az elégséges eredményt szerzett diákok számát. 
        /// Elégségesnek számít minden szám, ami nagyobb vagy egyenlő, mint 50 és kisebb vagy egyenlő, mint 60.
        /// </summary>
        public int Elegseges
        {
            get
            {
                return pontok.Where(x => x >= 50 && x <= 60).Count();
            }
        }


        /// <summary>
        /// Megszámolja és vissza adja a közepes eredményt szerzett diákok számát. 
        /// Közepesnek számít minden szám, ami nagyobb vagy egyenlő, mint 61 és kisebb vagy egyenlő, mint 70.
        /// </summary>
        public int Kozepes
        {
            get
            {
                return pontok.Where(x => x >= 61 && x <= 70).Count();
            }
        }


        /// <summary>
        /// Megszámolja és vissza adja a jó eredményt szerzett diákok számát. 
        /// Jónak számít minden szám, ami nagyobb vagy egyenlő, mint 71 és kisebb vagy egyenlő, mint 80.
        /// </summary>
        public int Jo
        {
            get
            {
                return pontok.Where(x => x >= 71 && x <= 80).Count();
            }
        }


        /// <summary>
        /// Megszámolja és vissza adja a jeles eredményt szerzett diákok számát. 
        /// Jelesnek számít minden szám, ami nagyobb vagy egyenlő, mint 81 és kisebb vagy egyenlő, mint 100.
        /// </summary>
        public int Jeles
        {
            get
            {
                return pontok.Where(x => x >= 81).Count();
            }
        }


        /// <summary>
        /// Vissza adja, hogya kivalo tanulok számánál lett-e több jeles osztályzat (db).
        /// A kivalok számát 0-tól kezdődően várja  a  függvény.
        /// </summary>
        /// <param name="kivalok">A kiválló eredményt elért diákok száma (db)</param>
        /// <returns>(Pl.: kivalok=5 esetén 6 db jeles osztályzat született, akkor a  visszatérési  érték  IGAZ  lesz!</returns>
        /// <exception cref="ArgumentException">Kivételt dob, ha a megadott érték kisebb, mint nulla vagy üres vagy nagyobb mint a pontok darabszáma.</exception>
        public bool Gyanus(int kivalok)
        {
            if (kivalok < 0 || kivalok == null || kivalok > pontok.Count())
            {
                throw new ArgumentException(nameof(kivalok));
            }
            if (kivalok > Jeles)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// Vissza adja, hogy a dolgozat érvénytelen-e, és újra kell írni.
        /// A dolgozat akkorlesz érvénytelen, ha a tanulók legalább fele nem írt dolgozatot.
        /// </summary>
        public bool Ervenytelen
        {
            get
            {
                bool ervenytelen = true;
                int nemIrt = pontok.Where(x => x == -1).Count();

                if (nemIrt < (pontok.Count()/2))
                {
                    ervenytelen = false;
                    return ervenytelen;
                }
                return ervenytelen;
            }
        }

        /// <summary>
        /// Kitörli a pontok lista tartalmát a teszteléshez.
        /// </summary>
        public void PontokTorol()
        {
            pontok.Clear();
        }
    }
}