using DolgozatProject;
using NUnit.Framework;
using System;

namespace TestDolgozatProject
{
    public class Tests
    {
        Dolgozat dolgozat = new Dolgozat();

        [SetUp]
        public void Setup()
        {
            dolgozat.PontokTorol();
        }

        [Test]
        public void MegirtaMindenkiTrue()
        {
            dolgozat.PontFelvesz(70);
            dolgozat.PontFelvesz(80);
            dolgozat.PontFelvesz(1);
            dolgozat.PontFelvesz(0);

            Assert.True(dolgozat.MindenkiMegirta());
        }

        [Test]
        public void MegirtaMindenkiFalse()
        {
            dolgozat.PontFelvesz(70);
            dolgozat.PontFelvesz(80);
            dolgozat.PontFelvesz(0);
            dolgozat.PontFelvesz(-1);
            Assert.False(dolgozat.MindenkiMegirta());
        }

        [Test]
        public void PontFelveszUres()
        {

            Assert.Throws<ArgumentNullException>(
                () => dolgozat.PontFelvesz(int.Parse(null)));
        }

        [Test]
        public void HelytelenPontFelvesz()
        {
            Assert.Throws<ArgumentException>(
                () => dolgozat.PontFelvesz(120));
        }

        [Test]
        public void Ervenytelen()
        {

            dolgozat.PontFelvesz(-1);
            dolgozat.PontFelvesz(-1);
            dolgozat.PontFelvesz(80);
            dolgozat.PontFelvesz(91);
            dolgozat.PontFelvesz(-1);
            dolgozat.PontFelvesz(-1);
            dolgozat.PontFelvesz(-1);
            dolgozat.PontFelvesz(-1);
            dolgozat.PontFelvesz(-1);
            dolgozat.PontFelvesz(75);
            Assert.IsTrue(dolgozat.Ervenytelen);


        }

        [Test]
        public void Ervenyes()
        {
            dolgozat.PontFelvesz(-1);
            dolgozat.PontFelvesz(74);
            dolgozat.PontFelvesz(80);
            dolgozat.PontFelvesz(91);
            dolgozat.PontFelvesz(67);
            dolgozat.PontFelvesz(-1);
            Assert.IsFalse(dolgozat.Ervenytelen);

        }

        [Test]
        public void VanBukas()
        {
            dolgozat.PontFelvesz(34);
            dolgozat.PontFelvesz(42);
            dolgozat.PontFelvesz(29);
            dolgozat.PontFelvesz(84);
            dolgozat.PontFelvesz(75);
            dolgozat.PontFelvesz(-1);
            Assert.AreEqual(3, dolgozat.Bukas);
        }

        [Test]
        public void NincsBukas()
        {
            dolgozat.PontFelvesz(74);
            dolgozat.PontFelvesz(82);
            dolgozat.PontFelvesz(99);
            dolgozat.PontFelvesz(84);
            dolgozat.PontFelvesz(75);
            dolgozat.PontFelvesz(-1);
            Assert.AreEqual(0, dolgozat.Bukas);
        }

        [Test]
        public void Gyanus()
        {
            dolgozat.PontFelvesz(85);
            dolgozat.PontFelvesz(82);
            dolgozat.PontFelvesz(99);
            dolgozat.PontFelvesz(84);
            dolgozat.PontFelvesz(75);
            dolgozat.PontFelvesz(-1);
            Assert.IsTrue(dolgozat.Gyanus(6));
        }

        [Test]
        public void NemGyanus()
        {
            dolgozat.PontFelvesz(85);
            dolgozat.PontFelvesz(82);
            dolgozat.PontFelvesz(99);
            dolgozat.PontFelvesz(84);
            dolgozat.PontFelvesz(75);
            dolgozat.PontFelvesz(-1);
            Assert.IsFalse(dolgozat.Gyanus(3));
        }

        [Test]
        public void HelytelenKivalokErtekMinusz()
        {
            dolgozat.PontFelvesz(85);
            dolgozat.PontFelvesz(82);
            dolgozat.PontFelvesz(99);
            dolgozat.PontFelvesz(60);
            dolgozat.PontFelvesz(-1);
            dolgozat.PontFelvesz(74);

            Assert.Throws<ArgumentException>(
            () => dolgozat.Gyanus(-5));


        }

        [Test]
        public void HelytelenKivalokErtekNull()
        {
            dolgozat.PontFelvesz(85);
            dolgozat.PontFelvesz(82);
            dolgozat.PontFelvesz(99);
            dolgozat.PontFelvesz(60);
            dolgozat.PontFelvesz(-1);
            dolgozat.PontFelvesz(74);


            Assert.Throws<ArgumentNullException>(
               () => dolgozat.Gyanus(int.Parse(null)));
        }

        [Test]
        public void HelytelenKivalokErtekMagasabb()
        {
            dolgozat.PontFelvesz(85);
            dolgozat.PontFelvesz(82);
            dolgozat.PontFelvesz(99);
            dolgozat.PontFelvesz(60);
            dolgozat.PontFelvesz(-1);
            dolgozat.PontFelvesz(74);

            Assert.Throws<ArgumentException>(
                () => dolgozat.Gyanus(8));
        }

        [Test]
        public void Elegseges()
        {
            dolgozat.PontFelvesz(74);
            dolgozat.PontFelvesz(82);
            dolgozat.PontFelvesz(50);
            dolgozat.PontFelvesz(55);
            dolgozat.PontFelvesz(60);
            dolgozat.PontFelvesz(-1);
            Assert.AreEqual(3, dolgozat.Elegseges);
        }

        [Test]
        public void Kozepes()
        {
            dolgozat.PontFelvesz(74);
            dolgozat.PontFelvesz(82);
            dolgozat.PontFelvesz(61);
            dolgozat.PontFelvesz(69);
            dolgozat.PontFelvesz(70);
            dolgozat.PontFelvesz(-1);
            Assert.AreEqual(3, dolgozat.Kozepes);
        }

        [Test]
        public void Jo()
        {
            dolgozat.PontFelvesz(74);
            dolgozat.PontFelvesz(80);
            dolgozat.PontFelvesz(71);
            dolgozat.PontFelvesz(69);
            dolgozat.PontFelvesz(70);
            dolgozat.PontFelvesz(-1);
            Assert.AreEqual(3, dolgozat.Jo);
        }

        [Test]
        public void Jeles()
        {
            dolgozat.PontFelvesz(74);
            dolgozat.PontFelvesz(80);
            dolgozat.PontFelvesz(81);
            dolgozat.PontFelvesz(88);
            dolgozat.PontFelvesz(100);
            dolgozat.PontFelvesz(-1);
            Assert.AreEqual(3, dolgozat.Jeles);
        }



    }
}